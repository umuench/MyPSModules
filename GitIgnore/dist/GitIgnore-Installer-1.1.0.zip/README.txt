GitIgnore Installer (fuer Umschueler Fachinformatiker)
=====================================================

Dieses Paket installiert ein PowerShell-Modul, das .gitignore-Dateien erstellt.
Es enthaelt auch fertige Vorlagen (Templates).

INHALT
------
- GitIgnore\   (Moduldateien)
- Templates\   (Vorlagen)
- Install.ps1  (Installer)
- INSTALL.md   (ausfuehrliche Anleitung)

SCHNELLSTART
------------
1) ZIP entpacken
2) PowerShell im entpackten Ordner oeffnen
3) Installer starten:

   .\Install.ps1

HILFE
-----
Bei Fragen: INSTALL.md lesen.
