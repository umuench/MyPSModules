# Installation (einfach erklaert)

Diese Anleitung ist fuer Umschueler zum Fachinformatiker gedacht.
Du brauchst nur PowerShell und Git fuer Windows.

## 1) ZIP entpacken

Entpacke die Datei z. B. nach `C:\Temp\GitIgnoreInstaller`.

## 2) PowerShell oeffnen

- Rechtsklick im entpackten Ordner -> **Terminal hier oeffnen**

## 3) Installieren

```powershell
.\Install.ps1
```

Das installiert:
- das Modul in deinen Benutzer-Ordner
- die Templates nach `C:\ProgramData\Git\Templates`

## Optional: Zielordner angeben

Wenn du einen anderen Ort nutzen willst:

```powershell
.\Install.ps1 -InstallPath "$HOME\Documents\PowerShell\Modules" -TemplatePath "C:\ProgramData\Git\Templates" -Force
```

## Nach der Installation testen

```powershell
Import-Module GitIgnore
New-GitIgnore
```

## FAQ fuer Anfaenger

**1) Was ist eine .gitignore?**
Eine `.gitignore` sagt Git, welche Dateien nicht eingecheckt werden sollen (z. B. `node_modules`, `.venv`, Build-Ordner).

**2) Muss ich Git vorher installieren?**
Ja. Die Templates liegen standardmaessig unter `C:\ProgramData\Git\Templates`. Das Verzeichnis kommt mit Git fuer Windows.

**3) Warum kommt die Meldung "Zugriff verweigert"?**
Dann fehlen Administratorrechte, z. B. wenn in `C:\ProgramData` geschrieben wird. Starte PowerShell als Administrator oder nutze `-TemplatePath` in einen Benutzerordner.

**4) Wo liegt mein Modul nach der Installation?**
Standard ist:
- PowerShell 7+: `C:\Users\<DEINNAME>\Documents\PowerShell\Modules\GitIgnore`
- Windows PowerShell 5.1: `C:\Users\<DEINNAME>\Documents\WindowsPowerShell\Modules\GitIgnore`

**5) Wie pruefe ich, ob das Modul geladen werden kann?**

```powershell
Import-Module GitIgnore
Get-Command New-GitIgnore
```

## Typische Fehler

- **Administratorrechte erforderlich**: PowerShell als Administrator starten.
- **Templates fehlen**: Stelle sicher, dass `Templates\` im ZIP enthalten ist.
- **Modul nicht gefunden**: Modulpfad pruefen:

```powershell
$env:PSModulePath -split ';'
```
