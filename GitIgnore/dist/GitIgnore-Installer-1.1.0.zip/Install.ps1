param(
    [switch]$AllUsers,
    [string]$InstallPath,
    [string]$TemplatePath = "C:\ProgramData\Git\Templates",
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

function Test-Admin {
    $current = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($current)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

$moduleName = 'GitIgnore'
$moduleSrc = Join-Path $PSScriptRoot $moduleName
$templatesSrc = Join-Path $PSScriptRoot 'Templates'

if (-not (Test-Path $moduleSrc)) { throw "Module source not found: $moduleSrc" }
if (-not (Test-Path $templatesSrc)) { throw "Templates source not found: $templatesSrc" }

if (-not $InstallPath) {
    if ($AllUsers) {
        $InstallPath = Join-Path $env:ProgramFiles 'WindowsPowerShell\Modules'
    } else {
        if ($PSVersionTable.PSEdition -eq 'Core') {
            $InstallPath = Join-Path $HOME 'Documents\PowerShell\Modules'
        } else {
            $InstallPath = Join-Path $HOME 'Documents\WindowsPowerShell\Modules'
        }
    }
}

$needsAdmin = $false
if ($AllUsers) { $needsAdmin = $true }
if ($TemplatePath -like "$env:ProgramData*") { $needsAdmin = $true }
if ($InstallPath -like "$env:ProgramFiles*") { $needsAdmin = $true }

if ($needsAdmin -and -not (Test-Admin)) {
    throw 'Administratorrechte erforderlich fuer AllUsers/TemplatePath/InstallPath in Systemordnern.'
}

$moduleDest = Join-Path $InstallPath $moduleName
New-Item -ItemType Directory -Force -Path $moduleDest | Out-Null
Copy-Item -Recurse -Force:$Force -Path $moduleSrc\* -Destination $moduleDest

New-Item -ItemType Directory -Force -Path $TemplatePath | Out-Null
Get-ChildItem -Path $templatesSrc -Filter '.gitignore*' -File | ForEach-Object {
    $dest = Join-Path $TemplatePath $_.Name
    Copy-Item -Force:$Force -Path $_.FullName -Destination $dest
}

Write-Host "Installation abgeschlossen." -ForegroundColor Green
Write-Host "Modulpfad: $moduleDest" -ForegroundColor Gray
Write-Host "Templates:  $TemplatePath" -ForegroundColor Gray
